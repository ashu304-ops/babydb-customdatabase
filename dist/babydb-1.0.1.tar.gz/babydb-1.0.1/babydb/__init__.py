from .core import SimpleDB

__version__ = "1.0.0"