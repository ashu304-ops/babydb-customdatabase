import babydb
print(babydb.__version__)